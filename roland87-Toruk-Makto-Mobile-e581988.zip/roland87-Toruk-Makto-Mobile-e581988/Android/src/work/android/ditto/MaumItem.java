package work.android.ditto;

public class MaumItem{
	int 	Img;
	String 	Name;
	String 	Maum;

	MaumItem(int img, String name, String maum){
		Img = img;
		Name = name;
		Maum = maum;
	}
}