/** Automatically generated file. DO NOT MODIFY */
package work.android.ditto;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}