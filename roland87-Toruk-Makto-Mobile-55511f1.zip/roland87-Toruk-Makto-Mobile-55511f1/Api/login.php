<?php
/*
 *  2012-05-14 
 *	uuid, timestamp, signature	/	token
 */
?>
