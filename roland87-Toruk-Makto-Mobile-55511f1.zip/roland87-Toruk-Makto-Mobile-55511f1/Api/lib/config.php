<?php
/*
 * Created on 2012. 5. 15.
 *
 */
 
// MySQL Config
$db_hostname	= 'localhost';
$db_username	= 'ditto';
$db_pw			= 'dir/w-2';

// Error Config
$debug_mode				= true;
// false 	�� mailing On,	emit err Off
// true 	�� mailing Off,	emit err On
$system_operator_mail 	= 'roland.blain@gmail.com';
$system_from_mail 		= 'info@ditto.com';

?>
